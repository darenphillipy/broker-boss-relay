# Broker Boss Online — v68.18 (Patch Batch #2)

Built on v68.17 (live-verified on 2026-10-09).

**Deploy both at once:**
- cPanel/Bluehost: `engine.bundle.js`, `app.js`, `index.html`, `style.css`, and the **new file `uiMessages.js`**.
- Render: the new `engine.bundle.js` next to `relay-server.js`. `relay-server.js` itself didn't change.

Cache-busting: `style.css?v=61`, `engine.bundle.js?v=57`, `uiMessages.js?v=1`, `app.js?v=61`.

## Files changed

| File | What changed |
| --- | --- |
| `engine.bundle.js` | #1 card IDs, #2 Cloud Infrastructure, Proprietary Algorithm, Hostile Takeover, build stamp |
| `uiMessages.js` (new) | Presentation-only text: friendly error messages and the public Action Log. No game rules. |
| `app.js` | Uses `uiMessages.js` for errors, the log and Round Summary names; New Year Strategic Planning picker; build stamp |
| `index.html` | Loads `uiMessages.js` before `app.js`; version strings |
| `style.css` | One rule: greyed-out track buttons in the New Year Strategic Planning picker |

## 1. Duplicate action-card IDs

**Root cause:** Card IDs came from about 15 different schemes.
- Some were stamped with the round number, like `ac-p2-startacquire-r4-0` or `ac-p1-botacquire-r3`. These repeat whenever the same effect fires twice in a round.
- Several modules kept their own counters that reset at game start. On the relay server those counters are shared by every room at once.

Playing, discarding and trashing all find cards by ID, so a duplicate removed **both** cards. On v68.17, 8 of 30 all-bot games had duplicates.

**Fix (`cardEffectHelpers.js`):**
- New `createActionCardIdAllocator(state)` and `generateUniqueActionCardInstanceId(state, playerId, tag)`. They scan every card ID held by any player (hand, discard pile, draw pile) and never hand out one that's taken, including IDs handed out earlier in the same batch.
- Every place that creates a card mid-game now uses it: end-of-round redraw, Open Market acquire, bot acquire, Trend Forecasting, market and blind draws, Data Analysis, Property Tour, STR_089, Clear Open Market pick, Free Action token acquire, Snoop replacement, Clean Slate, Silicon Valley Sweep, Cloud Infrastructure and Proprietary Algorithm.

## 2. Card logic

**Cloud Infrastructure (Technology B, Lv 7):** It drew only what was left in the draw pile, usually 2 cards. It now draws 3 and reshuffles your discard pile into a new draw pile if the draw pile runs out (the rulebook's "Critical Exception"). It still gives +2 hand size. Both this and Proprietary Algorithm use a new shared `drawFromPersonalDeck()` helper.

**Proprietary Algorithm (Technology B, Lv 5):** The real bug was a mismatch. The dashboard button sent `trash_for_draw`, but the engine only accepted `trash_for_cards`. So "Trash 1 → Draw 2" returned an error, did nothing, and never locked. Now:
- both names are accepted;
- the trashed card is removed from the game (not discarded);
- 2 cards are drawn, reshuffling the discard pile if needed;
- the ability locks for the round, and a second use is refused with "You already used that ability this round."

**The Hostile Takeover (Specialist 13):** Claiming it saved a "1st player next round" flag, but nothing ever read it. Now:
- At the end-of-round turn-order resolution, the claimer goes 1st no matter what anyone bid. Everyone else keeps their bid order.
- The claimer's first turn of the new round is two placements back-to-back before player 2 places anything. Nobody else gets this, and it doesn't carry into later rounds.
- This works for bots and for you: after your first placement it's still your turn.
- If the claimer has no second meeple, play simply moves on.
- Claiming it in Round 7 has no effect, because there is no Round 8.

## 3. UI and log clean-up

**Friendly error messages (`uiMessages.js`):** All 43 places in `app.js` that showed a raw engine code now show plain English. For example:
- `Recruit rejected: NO_MATCHING_VALUE` → "Recruit: You don't meet any of this Agent's values yet — raise Training, Technology or Recognition to at least one of their numbers."
- `INSUFFICIENT_FUNDS_FOR_PLACEMENT` → "Not enough Profit Tokens — this space costs $4 PT and you have $3 PT."

About 50 codes have their own wording. Any other code shows a general sentence on screen, and the raw code still goes to the browser console for debugging.

**Action Log:**
- Built from the real engine log, now showing the last 60 public lines (was 30).
- Internal bookkeeping is hidden: bot decision records, "awaiting choice" markers and board-reset sweeps.
- Meeple placements, card plays, Specialist hires, round starts, turn order and Meeple Tax are written as plain sentences.
- Player IDs (`p1`–`p6`), agent IDs (`A47`), card IDs (`GRW_037`, `S3`) and space IDs (`OPS_TECHNOLOGY`) become real names.
- "You" lines read correctly: "You's" → "Your", "You recruits" → "You recruit", "refresh their hand" → "refresh your hand".

**Round Summary:** Shows player names instead of `p1`–`p6`. It was reading a name field that doesn't exist.

**New Year Strategic Planning (S1):**
- You get exactly 1 track raise per card discarded, up to 2.
- Track buttons grey out once your raises equal your discards, and a 3rd card can't be ticked.
- Unticking a card removes the last raise.
- Confirm only unlocks when raises equal discards. Discarding nothing and confirming is still allowed.

## Verification

| Check | Result |
| --- | --- |
| Batch #2 suite (10 tests: card IDs, Cloud Infrastructure, Proprietary Algorithm in both modes, Hostile Takeover for bots and the human, two market acquires in one round) | v68.17: 1 of 9 pass (written before the 10th test). v68.18: 10 of 10 pass. |
| Batch #1 suite (15 tests) on v68.18 | 15 of 15 pass, no regressions |
| 40 human + 5-bot games and 40 all-bot games (2–6 players) | 80 of 80 finish at Round 7, 0 violations |
| 100 all-bot 6-player games | 0 duplicate card IDs, 0 errors, all finished. Every new card-ID path that bots use was hit at least once. |
| Relay server, full 1 + 5 room game over WebSocket | Ends at Round 7 |
| Real `index.html` in headless Chromium | Friendly messages show for Hire Staff and Recruit refusals. The New Year Strategic Planning cap behaves as described above. The Action Log has no internal codes or raw IDs. 2 full 1 + 5 games reach "Round 7 / 7" Final Scoring with no page errors. |

## Noticed, not changed

- When the Random bot rolls an archetype that's already taken, you get repeated names like "Vince … II / III". That's a naming choice in the lobby.
- Bots still bid PT for turn order even when The Hostile Takeover already guarantees them 1st. A small bot-strategy tweak if you want it.
